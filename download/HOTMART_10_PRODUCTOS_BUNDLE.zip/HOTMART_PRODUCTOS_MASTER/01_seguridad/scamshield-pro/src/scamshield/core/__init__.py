"""ScamShield Pro — Core package."""
