"""LicitAlert — Core."""
