# Learnings — ZOLO

Correcciones, insights, huecos de conocimiento y mejores prácticas capturados EN CALIENTE durante la operación (regla 31, v6.0 — patrón self-improving-agent).

**Categorías**: corrección | insight | hueco_conocimiento | mejor_práctica
**Formato**: entrada de 5 campos (CONTEXTO / PASÓ / LECCIÓN / CATEGORÍA / PROMOCIÓN) — ver skill `ledger-autoaprendizaje` §2. Solo append; las correcciones SUPERSEDEN (regla 24).

---

### api-imagenes-devuelve-jpeg — 25-oct-2026 (Task 125-B)
- CONTEXTO: pipeline de medios de ZOLO NEWS (generación de imágenes para el noticiero)
- PASÓ: la API de generación devuelve JPEG (JFIF) aunque el contrato del skill diga PNG
- LECCIÓN: verificar la FIRMA del archivo (magic bytes) antes de consumir cualquier binario generado por una API
- CATEGORÍA: corrección
- PROMOCIÓN: normalización automática por firma implementada en src/media/images.js (ffmpeg) + regla de oro §6.5 de skill noticiero-matutino + eval E54

### ffmpeg-concat-imagenes-duraciones — 25-oct-2026 (Task 125-B)
- CONTEXTO: ensamblado del MP4 del noticiero con concat demuxer
- PASÓ: la "última imagen repetida" hereda la última duration y estira el timeline; -r 30 como opción de salida duplica la primera slide; -shortest es inestable (77s vs 21s entre corridas)
- LECCIÓN: en concat de imágenes fijar fps como filtro de video (-vf fps=30) y capar con -t <duración_audio+0.05> — el resultado queda clavado al audio (Δ verificado 0.05s)
- CATEGORÍA: corrección
- PROMOCIÓN: implementado en src/media/video.js + regla de oro §6 de skill noticiero-matutino

### drawtext-solo-textfile — 25-oct-2026 (Task 125-B)
- CONTEXTO: captions en español (tildes, comas, comillas, %) sobre slides del noticiero
- PASÓ: texto inline en el filtro drawtext rompe con escapado de caracteres especiales
- LECCIÓN: drawtext SIEMPRE con textfile=<archivo temporal> + expansion=none — las tildes y comillas viajan seguras
- CATEGORÍA: mejor_práctica
- PROMOCIÓN: implementado en video.js + regla de oro §6.4 de skill noticiero-matutino

### fuentes-verificadas-antes-de-config — 25-oct-2026 (Task 125-A/integración)
- CONTEXTO: feeds RSS iniciales del noticiero (config.json)
- PASÓ: 3 de 5 feeds iniciales estaban muertos en vivo (Infobae 404, El Universo 404, El Comercio anti-bot) pese a ser feeds conocidos
- LECCIÓN: ninguna fuente (feed/API) entra a config sin verificación EN VIVO (código HTTP + contenido parseable); el sistema además debe saltar feeds caídos sin tumbar el run
- CATEGORÍA: mejor_práctica
- PROMOCIÓN: regla de oro §6.2 de skill noticiero-matutino + eval E55 + config.json reemplazada por 5 feeds verificados (Google News EC/Tec, BBC Mundo, France24 es, eJu.tv)
