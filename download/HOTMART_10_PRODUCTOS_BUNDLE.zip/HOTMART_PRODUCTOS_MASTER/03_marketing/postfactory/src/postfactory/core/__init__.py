"""PostFactory — Core."""
