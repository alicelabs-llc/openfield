"""MenuQR Pro — Core."""
